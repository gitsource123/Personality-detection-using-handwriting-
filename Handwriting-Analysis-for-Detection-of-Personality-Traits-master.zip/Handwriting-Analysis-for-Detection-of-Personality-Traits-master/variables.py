
img_rows, img_cols = 256, 256

batch_size = 7
# 4 difference characters
num_classes = 4
# very short training time
epochs = 100


model_json_path = 'model_files/model.json'
label_obj_path = 'model_files/labels.sav'
model_path = 'model_files/model.h5'

prediction_file_dir_path = 'predict_this_doc/'
