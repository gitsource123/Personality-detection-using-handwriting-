Setup:
 pip install -r requirements.txt


Train:
 1. python model_training.py  

Predict:
 1. Put a .jpg file inside 'predict_this_doc'
 2. python prediction.py          

